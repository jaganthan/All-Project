package org.edu;

public class Education {
	
	public void ug() {
		System.out.println("UG in Capital");
	}
	public void pg() {
		System.out.println("PG in Capital");
	}
}
