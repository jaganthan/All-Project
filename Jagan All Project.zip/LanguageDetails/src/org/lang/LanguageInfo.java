package org.lang;

public class LanguageInfo {

	public void tamilLanguage() {
		// TODO Auto-generated method stub
		System.out.println("Tamil");
	}
	
	public void englishLanguage() {
		// TODO Auto-generated method stub
			
	}
	
	public void hindilanguage() {
		// TODO Auto-generated method stub
		
		
	}
	
	public static void main(String[] args) {
		
		LanguageInfo l = new LanguageInfo();
		
		l.tamilLanguage();
		l.englishLanguage();
		l.hindilanguage();
		
		System.out.println("Done");
	}

}
