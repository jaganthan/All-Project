package org.stat;

public class Satic1 {
	
	//This is Static Variable
	public static String name = "Jagan";
	
	//This is Final-----cant be modified
	final float avg = 25.45454f;
	
	//This is Static Method
	public static void stdId() {
		
		System.out.println("5646");
	}
		
}
