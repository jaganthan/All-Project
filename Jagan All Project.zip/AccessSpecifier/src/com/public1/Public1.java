package com.public1;

public class Public1 {
	
	public void stdId() {
		
		System.out.println("4567");
		
	}

}
