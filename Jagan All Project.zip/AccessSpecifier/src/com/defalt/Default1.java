package com.defalt;
import com.defalt.Default2;

public class Default1 extends Default2 {
	
	public static void main(String[] args) {
		
		Default1 q = new Default1();
				q.stdGender();
	}

}
