package com.stepdefinition;

import com.baseclass.BaseClass;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends BaseClass {
	
	@Before
	public void beforeScanario()
	{
		launchBrowser();
		maximize();
		passUrl("https://facebook.com");
		System.out.println("Browser Launched Sucesfully");
	}
	
	@After
	public void afterScanario()
	{
		facebook.quit();
		System.out.println("Browser Closed");
	}
}
