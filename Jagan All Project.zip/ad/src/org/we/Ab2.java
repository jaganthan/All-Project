package org.we;

public class Ab2 extends Ab1
{
	@Override
	public void ug() {
		
		System.out.println();
	}
	public static void main(String[] args) {
		
		Ab2 n = new Ab2();
		n.ug();
	}
}


