package org.tamil;

import org.telegu.Telegu;

public class Tamil extends Telegu{

	public void tamillanguage() {
	
		System.out.println("Tamil");

	}
}

