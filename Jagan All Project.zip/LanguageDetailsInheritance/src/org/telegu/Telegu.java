package org.telegu;

public class Telegu {
	
	public void telgulanguage() {

		System.out.println("Telegu");

	}


}
