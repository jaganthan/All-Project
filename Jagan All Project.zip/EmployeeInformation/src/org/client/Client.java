package org.client;

public class Client {

		public void clientName() {
			// TODO Auto-generated method stub
			
			System.out.println("Jaganathan");
		}
		
		public static void main(String[] args) {
			
			Client c = new Client();
			
			c.clientName();
		}
}
