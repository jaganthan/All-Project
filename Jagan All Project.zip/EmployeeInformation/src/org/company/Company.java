package org.company;
import org.client.*;
public class Company extends Client {
		
	public void companyName() {
		// TODO Auto-generated method stub
		System.out.println("Greens Technologies");
	}
	
	public static void main(String[] args) {
		
		Company c = new Company();
		
		c.companyName();
		
	
	}
	
}
