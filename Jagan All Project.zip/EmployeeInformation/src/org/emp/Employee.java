package org.emp;
import org.project.*;

public class Employee extends Project  {

	private void empName() {
		
		
	}
	
	public static void main(String[] args)
	{
		Employee e = new Employee();
		e.clientName();
		e.companyName();
		e.empName();
		e.projectName();
		
	}
	
}
