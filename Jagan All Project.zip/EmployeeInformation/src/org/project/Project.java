package org.project;
import org.company.*;
public class Project extends Company {
	
	public void projectName() {
		// TODO Auto-generated method stub
			System.out.println("Testing");
	}
	
	
}
