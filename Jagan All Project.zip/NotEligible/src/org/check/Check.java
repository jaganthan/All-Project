package org.check;

public class Check {

	public static void main(String[] args) {
		
		int a=10;
		
		if(a==10)
		{
			System.out.println("Not Eligible");
		}
		else
		{
			System.out.println("Eligible");
		}
	}
}
