package com.stepdefinition;

import com.baseclass.BaseClass;
import com.pojoclass.Pojo;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition extends BaseClass {
	@Given("user has to launch chrome browser and pass the url")
	public void userHasToLaunchChromeBrowserAndPassTheUrl() {
		launchBrowser();
		maximize();
		passUrl("https://facebook.com");
		System.out.println("Browser Launched Sucessfully");
	}

	@When("user has to enter username and password")
	public void userHasToEnterUsernameAndPassword() {
		Pojo p = new Pojo();
		sendTxt(p.getTxtUser(), "Jaganathan");
		sendTxt(p.getTxtPass(), "jagan@123");
		System.out.println("Sucessfully Entered Username And Password");
	}

	@When("user has to click login button")
	public void userHasToClickLoginButton() {
		Pojo p = new Pojo();
		btnClick(p.getClk());
		System.out.println("Sucessfully Clicked Login Button");
	}

	@Then("navigate to home page")
	public void navigateToHomePage() {
		System.out.println("Navigated To HomePage Successfully");
	}

}
