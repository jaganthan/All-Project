package org.bike;

public interface Bike {

	void cost(long cost);
	void speed(float speed);
}
