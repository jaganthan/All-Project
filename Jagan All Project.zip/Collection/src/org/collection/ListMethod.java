package org.collection;

import java.util.ArrayList;
import java.util.List;

public class ListMethod {

	
	public static void main(String[] args) {
		
		List l = new ArrayList();
		
		l.add("jagan");
		l.add(26);
		l.add(2536.44);
		l.add(6463446464764l);
		l.add(true);
		
		System.out.println(l);
	
		
	}
}
