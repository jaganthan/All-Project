package org.whileloop;

public class WhileLoop {
	
	public static void main(String[] args) {
		
		int j = 3;
		
		while(j<=5)
		{
			System.out.println(j);
			j++;
		}
	}
}
//int j=3	3	3+1=4
//int j=4 	4 	4+1=5
//int j=5 	5	5+1=6
//int j=6 ------------------terminate
