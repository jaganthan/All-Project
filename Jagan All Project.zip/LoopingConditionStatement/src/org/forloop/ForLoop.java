package org.forloop;

public class ForLoop {
	public static void main(String[] args) {
		for(int i = 0 ; i<2 ; i++)
		{
			System.out.println(i);
		}
	}
	
}
// BACKGROUND EXECUTION STEPS
// int i=0 		0<2		0		0+1=1
// int i=1		1<2		1		1+1=2
// int i=2		2<2	------------terminate
 
