package org.dowhileloop;

public class DoWhileLoop {
	
	public static void main(String[] args) {
		
		int r = 1;
		do
		{
			System.out.println(r);
			r++;
		}
		while(r<=5);
	}
}
//int r=1 	1	1+1=2	2<=5
//int r=2 	2	2+1=3	3<=5
//int r=3	3	3+1=4	4<=5
//int r=4	4 	4+1=5	5<=5
//int r=5	5	5+1=6	6<=5
//-------------------terminate
