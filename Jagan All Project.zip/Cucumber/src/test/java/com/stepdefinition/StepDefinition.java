package com.stepdefinition;

import com.baseclass.BaseClass;
import com.pojoclass.Pojo;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition extends BaseClass {
	@Given("user has to launch chrome browser and pass the url")
	public void userHasToLaunchChromeBrowserAndPassTheUrl() {
		launchBrowser();
		maximize();
		passUrl("https://facebook.com");
		System.out.println("Sucessfully Browser Launched");
	}

	@When("user has to enter {string} and {string}")
	public void userHasToEnterAnd(String user, String pass) {
		Pojo p = new Pojo();
		sendTxt(p.getTxtUser(),user);
		sendTxt(p.getTxtPass(), pass);
		System.out.println("Sucessfully Entered Username And Password");
	}

	@When("user has to click login button")
	public void userHasToClickLoginButton() {
		Pojo p = new Pojo();
		btnClick(p.getClk());
		System.out.println("Sucessfully Clicked Login Button");
	}

	@Then("navigate to home page")
	public void navigateToHomePage() {
		System.out.println("Sucessfully Navigated To HomePage");
	}

}
