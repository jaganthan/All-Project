package com.stepdefinition;

import java.util.List;

import com.baseclass.BaseClass;
import com.pojoclass.Pojo;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition extends BaseClass {
	@Given("user has to launch chrome browser and pass the url")
	public void userHasToLaunchChromeBrowserAndPassTheUrl() {
		launchBrowser();
		maximize();
		passUrl("https://facebook.com");
		System.out.println("Browser Launched Sucessfully");
	}

	@When("user has to enter username and password")
	public void userHasToEnterUsernameAndPassword(io.cucumber.datatable.DataTable dataTable) {
		List<String> li= dataTable.asList();
		String user = li.get(2);
		String pass = li.get(5);
		Pojo p = new Pojo();
		sendTxt(p.getTxtUser(), user);
		sendTxt(p.getTxtPass(), pass);
	}

	@When("user has to click login button")
	public void userHasToClickLoginButton() {
		Pojo p = new Pojo();
		btnClick(p.getClk());
		System.out.println("Sucessfully Clicked Login Button");
	}

	@Then("navigate to home page")
	public void navigateToHomePage() {
		System.out.println("Navigated To HomePage Successfully");
	}

}
