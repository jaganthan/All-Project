package org.computer;

public class Computer {
	
	//PARENTS CLASS 
	public void  computerMode1()
	{
		System.out.println("Computer Name : Zebronic");
	}


}
