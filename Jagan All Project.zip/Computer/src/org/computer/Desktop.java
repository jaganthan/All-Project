package org.computer;

//CHILD CLASS
public class Desktop extends Computer {
	
	public static void main(String[] args)
	{
		Desktop d = new Desktop();
		d.computerMode1();
	}
	
}
