package com.finalview;
import com.biodata.BioDataDetails;

public class FinalView {

public static void main(String[] args)
{
	BioDataDetails b = new BioDataDetails();
	b.personData();
	
}

}

