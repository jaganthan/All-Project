package com.test;

public class Employee {
	
	private void EmployeeId() {
		
		System.out.println("Your Id Number is 0505");
	}
	
	private void EmployeeName() {
		
		System.out.println("Your Name Is Jagan");
		
	}
	
	public static void main(String[] args) {
		
		Employee e = new Employee();
		
		e.EmployeeId();
		e.EmployeeName();
		
	}
	
}