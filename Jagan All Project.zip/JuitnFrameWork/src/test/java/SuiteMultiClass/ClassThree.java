package SuiteMultiClass;

import org.junit.Test;

public class ClassThree {
	@Test
	public void b()
	{
		System.out.println("Jothi");
	}
}
