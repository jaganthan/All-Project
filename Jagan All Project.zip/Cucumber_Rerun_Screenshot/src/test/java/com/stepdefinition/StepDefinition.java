package com.stepdefinition;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.junit.Assert;

import com.baseclass.BaseClass;
import com.pojoclass.Pojo;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition extends BaseClass {

	@When("user has to enter username and password")
	public void userHasToEnterUsernameAndPassword(io.cucumber.datatable.DataTable dataTable) throws IOException {
		List<Map<String, String>> list = dataTable.asMaps();
		Map<String, String> map = list.get(1);
		String user = map.get("username");
		String pass = map.get("password");
		Pojo p = new Pojo();
		sendTxt(p.getTxtUser(), user);
		sendTxt(p.getTxtPass(), pass);
		screenShot("valid_username_password");
		System.out.println("Sucessfully Entered Username and Password");
	}

	@When("user has to click login button")
	public void userHasToClickLoginButton() throws IOException {
		Pojo p = new Pojo();
		btnClick(p.getClk());
		screenShot("Login_Button_Clicked");
		System.out.println("Sucessfully Clicked Login Button");
	}

	@Then("navigate to home page")
	public void navigateToHomePage() throws IOException {
		screenShot("Navigated_To_HomePage");
		System.out.println("Navigated To HomePage Successfully");
	}

	// ==============================Failed Scenarios=====================

	@When("user  to enter username and password")
	public void userToEnterUsernameAndPassword() {
		Pojo p = new Pojo();
		sendTxt(p.getTxtUser(), "Manimaran");
		sendTxt(p.getTxtPass(), "mani@1345");
		System.out.println("text passed Sucessfully");
	}

	@When("click login button")
	public void clickLoginButton() {
		Assert.assertTrue(false);
		Pojo p = new Pojo();
		btnClick(p.getClk());
		System.out.println("failed to click button");
	}

	@Then("navigating to homepage")
	public void navigatingToHomepage() {
		System.out.println("Navigated To HomePage Unsuccessfull");
	}

}
