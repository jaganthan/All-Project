package com.runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.baseclass.JVMReport;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;

@RunWith(Cucumber.class)
@CucumberOptions(features = "@src\\test\\resources\\Rerun\\login.txt", glue = "com.stepdefinition", snippets = SnippetType.CAMELCASE, dryRun = false, plugin = {
		"html:target\\Report", "json:target\\Report\\facebook.json", "junit:target\\Report\\login.xml",
		"rerun:src\\test\\resources\\Rerun\\login.txt" })
public class TestReRun {
	@AfterClass

	public static void afterExecution() {
		JVMReport.generateJVMReport(System.getProperty("user.dir") + "\\target\\Report\\facebook.json");
	}
}
