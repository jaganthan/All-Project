package com.runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.baseclass.JVMReport;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;

@RunWith(Cucumber.class)
@CucumberOptions(features = "D:\\Jagan Project\\CucumberJVMReport\\src\\test\\resources", glue = "com.stepdefinition", snippets = SnippetType.CAMELCASE, dryRun = false, tags = {
		"@smoke or @sanity" }, plugin = { "html:target\\Report", "json:target\\Report\\facebook.json",
				"junit:target\\Report\\login.xml" })
public class TestRunner {
	@AfterClass

	public static void afterExecution() {
		JVMReport.generateJVMReport(System.getProperty("user.dir") + "\\target\\Report\\facebook.json");
	}
}
