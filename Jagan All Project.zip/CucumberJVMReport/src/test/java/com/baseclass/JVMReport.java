package com.baseclass;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class JVMReport {
	public static void generateJVMReport(String filename) {
		File file = new File(System.getProperty("user.dir") + "\\target\\JVM Report");
		Configuration c = new Configuration(file, "Facebook");
		c.addClassifications("Browser Name", "Chrome Browser");
		c.addClassifications("Browser Version", "97.0.4692.71");
		c.addClassifications("Platform", "Windows 10");
		c.addClassifications("Current Sprint", "5");
		List<String> li = new ArrayList<String>();
		li.add(filename);
		ReportBuilder r = new ReportBuilder(li, c);
		r.generateReports();

	}
}
