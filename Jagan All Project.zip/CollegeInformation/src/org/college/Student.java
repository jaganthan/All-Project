package org.college;

public class Student {

	public void studentName() {
		
		char Name = 'J';	
		System.out.println("Name :" + Name );
		
	}	
	
	public void studentDept() {
		
		
		System.out.println("Dept : CSE");
		
		
	}
	
	public void studentId() {
		
		
		System.out.println("ID : 210813104017");
		int Age = 26;
		System.out.println("Age : " + Age);
		
	}
	
				
}
	

