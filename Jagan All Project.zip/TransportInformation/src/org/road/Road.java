package org.road;

public class Road {

	public void bike() {
		
		System.out.println("Bike");
		
	}
	
	public void cycle() {
		
		System.out.println("Cycle");

	}
	
	public void bus() {
		
		System.out.println("Bus");

	}
	
	public void car() {
		
		System.out.println("Car");

	}
	
	
}
