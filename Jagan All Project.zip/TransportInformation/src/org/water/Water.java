package org.water;

public class Water {

	public void boat() {
		
		System.out.println("Boat");

	}
	
	public void ship() {
		
		System.out.println("Ship");
		
	}
	
}
