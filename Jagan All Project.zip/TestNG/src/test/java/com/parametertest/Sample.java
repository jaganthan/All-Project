package com.parametertest;

import java.util.Date;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Sample extends BaseClass{
	@BeforeClass
	public void run()
	{
		launchBrowser();
		maximize();
	}
	@BeforeMethod
	public void url()
	{
		passUrl("https://adactinhotelapp.com/");
	}
	@AfterClass
	public void end()
	{
		adactin.quit();
	}
	@AfterMethod
	public void getdate()
	{
		Date d = new Date();
		System.out.println(d);
	}
	
	@Parameters({"username","password"})
	@Test
	private void para(String user,String pass)
	{
		PojoClass p = new PojoClass();
		sendTxt(p.getUsername(), user);
		sendTxt(p.getPassword(), pass);
		buttonClick(p.getClick());
	}
}
