package com.suitmulticlass;

import org.testng.annotations.Test;

public class C {
	@Test
	public void name()
	{
		System.out.println("MANIMARAN C");
	}
	
	@Test
	public void age()
	{
		System.out.println("53");
	}
	@Test
	public void birthday()
	{
		System.out.println("17/10/1968");
	}
	@Test
	public void qualification()
	{
		System.out.println("Ass-Engg");
	}
}
