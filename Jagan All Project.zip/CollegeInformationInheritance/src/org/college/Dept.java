package org.college;

public class Dept extends College{

public void deptName() {
		
		System.out.println("All Dept");

	}
}
