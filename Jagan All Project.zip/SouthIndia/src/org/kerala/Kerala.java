package org.kerala;

import org.tamilnadu.TamilNadu;

public class Kerala extends TamilNadu {
	
	public void malayalam() {
		
		System.out.println("Launguage is : Malayalam");
	}

}
