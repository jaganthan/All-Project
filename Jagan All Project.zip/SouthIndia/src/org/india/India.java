package org.india;

import org.andrapradesh.Andrapradesh;

public class India extends Andrapradesh {
	
	public void india() {
	
		System.out.println("My Country is : India");
	}
	
	public static void main(String[] args) {
		
		India i = new India();
		
		i.india();
		i.telugu();
		i.malayalam();
		i.tamilLaunguage();
	}
}
