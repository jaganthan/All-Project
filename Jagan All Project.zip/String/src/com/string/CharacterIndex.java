package com.string;

public class CharacterIndex {

	public static void main(String[] args)
	{
		String s = "GreensTechnology";
		System.out.println(s);
		
		int i = s.indexOf('o');
		System.out.println(i);
	}
}
