package org.ifstate;

public class Con1 {

	public static void main(String[] args) {
		
		int wheat = 150;
		if (wheat == 150)
		{
			System.out.println("Wheet : 150rs");
		}
		
	}
}
