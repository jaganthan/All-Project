package org.elseifstate;

public class Con3 {
	
	public static void main(String[] args) {
		
	
	String Name ="JAGAN", Friend = "JONES", Friend2 = "KARTHIK";
	int age = 26, age2 = 27, age3 = 28;
	
	if(Name == "JAGN")
	{
		System.out.println("ID : 2014\n" + "AGE : " + age);
	}
	
	else if(Friend == "JONES")
	{
		System.out.println("ID : 1935\n" + "AGE : " + age2);
	}
	
	else if (Friend2 == "KARTHIK")
	{
		System.out.println("ID : 2301\n" + "AGE : " +age3);
	}
	else
	{
		System.out.println("No person Found");
	}
	//another Statement
	if(age>age2 || age3>age)
	{
		System.out.println("yes");
	
		if(Friend == "JONS")
		{
			System.out.println("Name : " + Friend);
		}
		else
		{
			System.out.println("No person Avalible");
		}
	}
	else
	{
		System.out.println("No");
	}
	


}
}
