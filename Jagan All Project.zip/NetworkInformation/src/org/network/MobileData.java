package org.network;

public class MobileData {

	public void dataName() {
		
		System.out.println("5G");

	}
	
	
}
