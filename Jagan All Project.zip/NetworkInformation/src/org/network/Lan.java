package org.network;

public class Lan {

	public void lanName() {
		
		System.out.println("WLAN");

	}
	
}
