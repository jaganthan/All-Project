package org.questioanswer;

import java.util.ArrayList;
import java.util.*;

public class ArrayListList {

	
	public static void main(String[] args) {
		
		
		List <Integer> a = new ArrayList<Integer>();
		
		a.add(10);
		a.add(20);
		a.add(30);
		a.add(90);
		a.add(10);
		a.add(10);
		a.add(40);
		a.add(50);
		                            		
		System.out.println(a.size());
	}
}
