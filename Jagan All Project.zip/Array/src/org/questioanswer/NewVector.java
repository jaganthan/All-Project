package org.questioanswer;

import java.util.List;
import java.util.Vector;

public class NewVector {

	public static void main(String[] args) {
		
		
		List<Integer> k = new Vector<Integer>();
		
		k.add(105);
		k.add(205);
		k.add(305);
		k.add(405);
		k.add(505);
		k.add(605);
		k.add(705);
		k.add(805);
		
		System.out.println(k.size());
	}
}
