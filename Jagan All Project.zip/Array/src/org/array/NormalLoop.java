package org.array;
public class NormalLoop {
	
	public static void main(String[] args) {
		
		String s[] = new String[5];
		
		s[0] = "jagan";
		s[1] = "Loke";
		s[2] = "jothi";
		s[3] = "angel";
		s[4] = "Pooja";
		
		
		//Normal for loop
		for(int i=0; i<s.length; i++)
		{
			
			System.out.println(s[i]);
		}
		
	}

}
